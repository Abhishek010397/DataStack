import boto3
import os 

def lambda_handler(event, context):
    instance_id = os.environ.get("INSTANCE_ID")
    ssm_client = boto3.client('ssm')
    response = ssm_client.send_command(
        InstanceIds=[instance_id],
        DocumentName='AWS-RunShellScript',
        Parameters={
            'commands': ['/home/ec2-user/batch_script.sh']
        }
    )
    command_id = response['Command']['CommandId']
    print(command_id)